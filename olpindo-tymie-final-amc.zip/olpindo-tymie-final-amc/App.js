import React, { useState } from 'react';
import { View, TextInput, Text, StyleSheet } from 'react-native';

const App = () => {
  const [temperature, setTemperature] = useState('');
  const [scale, setScale] = useState('F');
  const [backgroundColor, setBackgroundColor] = useState('#ECEDF3'); 

  const handleTemperatureChange = (text) => {
    if (!isNaN(text)) {
      setTemperature(text);
      updateBackgroundColor(text);
    }
  };

  const updateBackgroundColor = (text) => {
    const temp = parseFloat(text);
    let newColor;
    if (scale === 'F') {
      newColor = temp >= 32 ? '#F37B2B' : '#87CEEB'; // Fahrenheit
    } else {
      newColor = temp >= 0 ? '#87CEEB' : '#F37B2B'; // Celsius
    }
    setBackgroundColor(newColor);
  };

  const convertTemperature = () => {
    if (scale === 'F') {
      return ((parseFloat(temperature) - 32) * 5) / 9;
    } else {
      return (parseFloat(temperature) * 9) / 5 + 32;
    }
  };

  return (
    <View style={[styles.container, { backgroundColor }]}>
      <Text style={styles.title}>Temperature Converter</Text>
      <TextInput
        style={styles.input}
        onChangeText={handleTemperatureChange}
        value={temperature}
        keyboardType="numeric"
        placeholder="Enter temperature"
      />
      <Text style={styles.result}>
        {scale === 'F' ? 'Celsius: ' : 'Fahrenheit: '}
        {convertTemperature().toFixed(2)}
      </Text>
      <Text style={styles.scaleSwitch} onPress={() => setScale(scale === 'F' ? 'C' : 'F')}>
        Convert to {scale === 'F' ? '°C' : '°F'}
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    fontStyle: 'sun-sefif',
  },
  title: {
    fontSize: 15,
    fontWeight: 'bold',
    marginBottom: 15,
  },
  input: {
    width: '50%',
    height: 40,
    borderColor: 'black',
    borderWidth: 1.5,
    paddingHorizontal: 10,
    marginBottom: 15,
  },
  result: {
    fontSize: 15,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  scaleSwitch: {
    fontSize: 15,
    fontWeight: 'bold',
    color: 'blue', 


     
  },
});

export default App;
